package com.example.brimore2.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.example.brimore2.R;
import com.example.brimore2.data.models.main.dynamicsectionone.DynamicSectionDetails;
import com.example.brimore2.databinding.MainItemsSliderBinding;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class MainProductAdapter extends RecyclerView.Adapter<MainProductAdapter.MyHolder> {

    @NonNull
    @NotNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        MainItemsSliderBinding binding = DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.main_items_slider,parent,false);
        return new MyHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull MainProductAdapter.MyHolder holder, int position) {
        DynamicSectionDetails dynamicSectionVariant = dynamicSectionVariantList.get(position);
        holder.binding.setPorModel(dynamicSectionVariant);

    }

    @Override
    public int getItemCount() {
        return dynamicSectionVariantList !=null? dynamicSectionVariantList.size():0;
    }
    List<DynamicSectionDetails> dynamicSectionVariantList;
    Context context;
    public void setData(Context context, List<DynamicSectionDetails> dynamicSectionVariantList){
        this.context = context;
        this.dynamicSectionVariantList = dynamicSectionVariantList;
    }

    class MyHolder extends RecyclerView.ViewHolder {
        MainItemsSliderBinding binding;
        public MyHolder(@NonNull @NotNull MainItemsSliderBinding itemView) {
            super(itemView.getRoot());
            this.binding = itemView;
        }
    }
}
