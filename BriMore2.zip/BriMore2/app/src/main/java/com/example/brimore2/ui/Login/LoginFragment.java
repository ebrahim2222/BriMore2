package com.example.brimore2.ui.Login;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.brimore2.data.Api;
import com.example.brimore2.data.Modules;
import com.example.brimore2.data.models.LoginResponse;
import com.example.brimore2.data.Repositories;
import com.example.brimore2.R;
import com.example.brimore2.databinding.FragmentLoginBinding;

import org.jetbrains.annotations.NotNull;

import javax.inject.Inject;
import javax.inject.Named;

import dagger.hilt.android.AndroidEntryPoint;
import io.paperdb.Paper;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

@AndroidEntryPoint
public class LoginFragment extends Fragment {
    @Inject
    Api api;

    @Inject
    Repositories repositories;
    NavController controller;
    @Modules.userToken
    @Inject
    SharedPreferences preferences;
    ProgressDialog dialog;
    FragmentLoginBinding binding;
    private static final String TAG = "LoginFragment";
    public LoginFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Paper.init(requireContext());


    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        controller = Navigation.findNavController(view);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_login,container,false);
        View root = binding.getRoot();


        textChangColor();

        dialog = new ProgressDialog(requireContext());



        binding.loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog();
                String email = binding.emailField.getText().toString();
                String password = binding.passField.getText().toString();
                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(getContext(), "please enter your email", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(password)) {
                    Toast.makeText(getContext(), "please enter your password", Toast.LENGTH_SHORT).show();

                } else {
                    logIn(email,password);
                }
            }
        });


        return root;
    }

    private void textChangColor() {
        String txt1 = "Don’t have an account? Swipe right to";
        String txt2 = "create a new account.";
        String s1 = getColoredSpanned(txt1, "#515C6F");
        String s2 = getColoredSpanned(txt2, "#FF6969");
        binding.signupText.setText(Html.fromHtml(s1+" "+s2));
    }


    private void logIn(String email, String password) {
        Call<LoginResponse> loginApi = repositories.getLoginApi(email, password);
        loginApi.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(getContext(), "success", Toast.LENGTH_SHORT).show();
                    LoginResponse loginResponse = response.body();
                    LoginResponse.Data data = loginResponse.getData();
                    String token = data.getApiToken();
                    Log.d(TAG, "aly onResponse: "+token);
                    saveTokenInSharedPreference(token);
                    dialog.dismiss();
                    controller.navigate(R.id.action_viewPagerFragment_to_mainFragment);

                } else {
                    dialog.dismiss();
                    Toast.makeText(getContext(), "fail", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                dialog.dismiss();
                Log.d(TAG, "aly onFailure: "+t.getMessage());
                Toast.makeText(getContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void saveTokenInSharedPreference(String token) {

        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("token",token);
        editor.commit();
    }

    private String getColoredSpanned(String text, String color) {
        String input = "<font color=" + color + ">" + text + "</font>";
        return input;
    }

    private void showDialog(){
        dialog.setTitle("Loading");
        dialog.setMessage("Please wait");
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }
}