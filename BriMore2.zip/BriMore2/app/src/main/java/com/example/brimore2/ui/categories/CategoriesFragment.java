package com.example.brimore2.ui.categories;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.brimore2.adapters.CategoryAdapter;
import com.example.brimore2.data.Modules;
import com.example.brimore2.R;
import com.example.brimore2.data.models.main.maincategory.MainCategoryDetails;
import com.example.brimore2.databinding.FragmentCategoriesBinding;
import com.example.brimore2.ui.Splash.SplashActivity;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class CategoriesFragment extends Fragment {

    FragmentCategoriesBinding binding;
    CategoryViewModel CategoryViewModel;
    @Inject
    CategoryAdapter adapter;
    @Modules.userToken
    @Inject
    SharedPreferences preferences;
    private static final String TAG = "CategoriesFragment";
    private String token;

    public CategoriesFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        NavController controller = Navigation.findNavController(view);
        controller.addOnDestinationChangedListener(new NavController.OnDestinationChangedListener() {
            @Override
            public void onDestinationChanged(@NonNull @NotNull NavController controller, @NonNull @NotNull NavDestination destination, @Nullable @org.jetbrains.annotations.Nullable Bundle arguments) {

            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
         binding = DataBindingUtil.inflate(inflater,R.layout.fragment_categories,container,false);

         View view = binding.getRoot();
        setUpRecycler();
        getToken();

        CategoryViewModel = new ViewModelProvider(requireActivity()).get(CategoryViewModel.class);

        CategoryViewModel.getCategories(token);

        CategoryViewModel.mutableLiveData.observe(requireActivity(), new Observer<List<MainCategoryDetails>>() {
            @Override
            public void onChanged(List<MainCategoryDetails> data) {
                binding.categoryProgresBar.setVisibility(View.GONE);
                adapter.setData(requireContext(),data);
                adapter.notifyDataSetChanged();
            }
        });




        return view;

    }

    private void setUpRecycler() {
        LinearLayoutManager manager = new LinearLayoutManager(requireContext());
        binding.categoryRv.setLayoutManager(manager);
        binding.categoryRv.setAdapter(adapter);
    }

    public void getToken(){
        token = preferences.getString("token", "");
    }
}