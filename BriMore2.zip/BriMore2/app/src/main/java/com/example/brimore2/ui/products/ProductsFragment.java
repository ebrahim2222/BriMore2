package com.example.brimore2.ui.products;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.brimore2.R;
import com.example.brimore2.adapters.ProductAdapter;
import com.example.brimore2.data.Modules;
import com.example.brimore2.data.models.products.Datum;
import com.example.brimore2.databinding.FragmentProductsBinding;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.AndroidEntryPoint;


@AndroidEntryPoint
public class ProductsFragment extends Fragment {
    @Modules.userToken
    @Inject
    SharedPreferences userSharedPref;


    @Inject
    GridLayoutManager manager;

    ProductsViewModel viewModel;

    FragmentProductsBinding binding;

    @Inject
    ProductAdapter adapter;

    private static final String TAG = "ProductsFragment";
    public ProductsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_products,container,false);
        View view = binding.getRoot();
        viewModel = new ViewModelProvider(requireActivity()).get(ProductsViewModel.class);

        setUpRecycler();
        String token = userSharedPref.getString("token", "");

        SharedPreferences subShared = requireActivity().getSharedPreferences("subCatId",Context.MODE_PRIVATE);
        int id = subShared.getInt("id", 0);

        viewModel.getProducts(token,id);
        viewModel.mutableLiveData.observe(requireActivity(), new Observer<List<Datum>>() {
            @Override
            public void onChanged(List<Datum> data) {
                binding.productsProgresBar.setVisibility(View.GONE);
                Log.d(TAG, "onChanged: "+data);
                adapter.setData(requireContext(),data);
                adapter.notifyDataSetChanged();
            }
        });
        return view;
    }

    private void setUpRecycler() {
        //binding.productRv.setLayoutManager(manager);
        binding.productRv.setAdapter(adapter);

    }
}