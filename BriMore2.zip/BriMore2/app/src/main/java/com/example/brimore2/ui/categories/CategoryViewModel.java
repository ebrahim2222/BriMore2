package com.example.brimore2.ui.categories;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.brimore2.data.models.categories.Categories;
import com.example.brimore2.data.Repositories;
import com.example.brimore2.data.models.main.maincategory.MainCategoryDetails;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;
import dagger.hilt.android.qualifiers.ApplicationContext;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

@HiltViewModel
public class CategoryViewModel extends ViewModel {
    private static final String TAG = "CategoryViewModel";
    MutableLiveData<List<MainCategoryDetails>> mutableLiveData= new MutableLiveData<>();


    CompositeDisposable compositeDisposable;
    Repositories repositories;
    Context context;
    @Inject
    public CategoryViewModel(Repositories repositories, CompositeDisposable compositeDisposable, @ApplicationContext Context context) {
        this.repositories = repositories;
        this.compositeDisposable = compositeDisposable;
        this.context = context;
    }

    public void getCategories(String header){

        Observable<Categories> subCategoryApi = repositories.getCategoryApi("Bearer "+header);

       /*
        Observer<List<Categories>> categoriesObserver = new Observer<List<Categories>>() {
            @Override
            public void onSubscribe(@NotNull Disposable d) {

            }

            @Override
            public void onNext(@NotNull List<Categories> categories) {


            }

            @Override
            public void onError(@NotNull Throwable e) {
                Log.d(TAG, "aly onError: "+e.getMessage());
            }

            @Override
            public void onComplete() {

            }
        };
        subCategoryApi.subscribeOn(Schedulers.io());
        subCategoryApi.observeOn(AndroidSchedulers.mainThread());

        subCategoryApi.subscribe(categoriesObserver);*/
        compositeDisposable.add(subCategoryApi.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer<Categories>() {
            @Override
            public void accept(Categories categories) throws Exception {
                List<MainCategoryDetails> categoriesDetailsList = categories.getData();
                Log.d(TAG, "accept: "+ categoriesDetailsList);
                mutableLiveData.setValue(categoriesDetailsList);

            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                Toast.makeText(context, throwable.getMessage(), Toast.LENGTH_SHORT).show();
                Log.d(TAG, "accept: "+throwable);
            }
        }));


    }
}
