package com.example.brimore2.ui.subcategory;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.brimore2.R;
import com.example.brimore2.adapters.SubCategoryAdapter;
import com.example.brimore2.data.Modules;
import com.example.brimore2.data.models.main.maincategory.MainCategoryDetails;
import com.example.brimore2.databinding.FragmentSubCategoryBinding;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SubCategoryFragment extends Fragment {

    SubCategoryViewModel viewModel;

    @Modules.userToken
    @Inject
    SharedPreferences userPref;

    SharedPreferences catPref;

    @Inject
    SubCategoryAdapter adapter;

    FragmentSubCategoryBinding binding;

    private static final String TAG = "SubCategoryFragment";

    public SubCategoryFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_sub_category,container,false);
        View view = binding.getRoot();

        MainCategoryDetails categoriesDetails = getArguments().getParcelable("category");

        binding.fragmentSubTxt1.setText(categoriesDetails.getName());

        setUpRecycler();
        catPref = requireActivity().getSharedPreferences("categoryId", Context.MODE_PRIVATE);
        int id = catPref.getInt("id", 0);
        String token = userPref.getString("token", "");
        viewModel = new ViewModelProvider(requireActivity()).get(SubCategoryViewModel.class);
        viewModel.getSubCategory(token,id);

        viewModel.mutableLiveData.observe(requireActivity(), (Observer<? super List<MainCategoryDetails>>) new Observer<List<MainCategoryDetails>>() {
            @Override
            public void onChanged(List<MainCategoryDetails> data) {
                binding.subcategProgresBar.setVisibility(View.GONE);
                Log.d(TAG, "aly onChanged: "+data);
                adapter.setData(requireContext(),data);
                adapter.notifyDataSetChanged();
            }
        });


        return view;
    }

    private void setUpRecycler() {
        LinearLayoutManager manager = new LinearLayoutManager(requireContext(),LinearLayoutManager.HORIZONTAL,false);
        binding.subcategoryRv.setLayoutManager(manager);
        binding.subcategoryRv.setAdapter(adapter);
    }
}