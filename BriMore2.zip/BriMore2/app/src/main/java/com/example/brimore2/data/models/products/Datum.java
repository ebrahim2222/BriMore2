package com.example.brimore2.data.models.products;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Datum {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("brief")
    @Expose
    private String brief;
    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("brand")
    @Expose
    private Brand brand;
    @SerializedName("hot_deal")
    @Expose
    private Object hotDeal;
    @SerializedName("attributes")
    @Expose
    private List<Object> attributes = null;
    @SerializedName("variants")
    @Expose
    private List<Variant> variants = null;
    @SerializedName("tag_list")
    @Expose
    private List<Tag__1> tagList = null;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrief() {
        return brief;
    }

    public void setBrief(String brief) {
        this.brief = brief;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Brand getBrand() {
        return brand;
    }

    public void setBrand(Brand brand) {
        this.brand = brand;
    }

    public Object getHotDeal() {
        return hotDeal;
    }

    public void setHotDeal(Object hotDeal) {
        this.hotDeal = hotDeal;
    }

    public List<Object> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<Object> attributes) {
        this.attributes = attributes;
    }

    public List<Variant> getVariants() {
        return variants;
    }

    public void setVariants(List<Variant> variants) {
        this.variants = variants;
    }

    public List<Tag__1> getTagList() {
        return tagList;
    }

    public void setTagList(List<Tag__1> tagList) {
        this.tagList = tagList;
    }

}