package com.example.brimore2.ui.products;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.brimore2.data.Api;
import com.example.brimore2.data.Repositories;
import com.example.brimore2.data.models.products.Datum;
import com.example.brimore2.data.models.products.Products;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;
import dagger.hilt.android.qualifiers.ApplicationContext;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

@HiltViewModel
public class ProductsViewModel extends ViewModel {

    Api api;
    Repositories repositories;
    CompositeDisposable compositeDisposable;
    MutableLiveData<List<Datum>> mutableLiveData = new MutableLiveData<>();
    Context context;
    private static final String TAG = "ProductsViewModel";

    @Inject
    public ProductsViewModel(Api api, Repositories repositories,CompositeDisposable compositeDisposable,@ApplicationContext Context context) {
        this.api = api;
        this.repositories = repositories;
        this.compositeDisposable = compositeDisposable;
        this.context = context;
    }

    public  void getProducts(String header , int id)
    {
        Observable<Products> productsApi = repositories.getProductsApi("Bearer " +header, id);
        compositeDisposable.add(productsApi.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer<Products>() {
            @Override
            public void accept(Products products) throws Exception {
                List<Datum> data = products.getData();
                Log.d(TAG, "aly accept: "+data);
                mutableLiveData.setValue(data);

            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                Toast.makeText(context, throwable.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }));
    }
}
