package com.example.brimore2.data;


import com.example.brimore2.data.models.categories.Categories;
import com.example.brimore2.data.models.LoginResponse;
import com.example.brimore2.data.models.main.HomePage;
import com.example.brimore2.data.models.products.Products;

import javax.inject.Inject;

import io.reactivex.Observable;
import retrofit2.Call;

public class Repositories {
    Api api;
    @Inject
    public Repositories(Api api) {
        this.api = api;
    }

    public Call<LoginResponse> getLoginApi(String key, String password){
        return api.loginApi(key,password);
    }

    public Observable<Categories> getCategoryApi(String header ){
        return api.getCategories(header);
    }

    public Observable<HomePage> getMainSlider(String header){
        return api.HomeApi(header);
    }

    public Observable<Categories> getSubCategoryApi(String header , int id){
        return api.getSubCategoriesApi(header,id);
    }

    public Observable<Products> getProductsApi(String header , int id){
        return api.productsApi(header,id);
    }


    public Observable<Products> getProductsDetailsApi(String header , int id){
        return api.getProductsDetailsApi(header , id);
    }


}
