package com.example.brimore2.data;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.brimore2.adapters.CategoryAdapter;
import com.example.brimore2.adapters.MainBrandsAdapter;
import com.example.brimore2.adapters.MainItemAdapter;
import com.example.brimore2.adapters.MainProductAdapter;
import com.example.brimore2.adapters.ProductAdapter;
import com.example.brimore2.adapters.SubCategoryAdapter;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import javax.inject.Qualifier;
import javax.inject.Singleton;
import dagger.Module;
import dagger.Provides;
import dagger.hilt.InstallIn;
import dagger.hilt.android.qualifiers.ApplicationContext;
import dagger.hilt.components.SingletonComponent;
import io.reactivex.disposables.CompositeDisposable;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

@Module
@InstallIn(SingletonComponent.class)
public class Modules {
    String baseUrl = "https://test.hercules.brimore.com/";

    @Provides
    @Singleton
    public Retrofit provideRetrofit(){
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(interceptor)
                .build();
        Retrofit.Builder builder = new Retrofit.Builder();
        builder.baseUrl(baseUrl);
                builder.addConverterFactory(GsonConverterFactory.create());
                builder.addCallAdapterFactory(RxJava2CallAdapterFactory.create());
                builder.client(client);
        Retrofit retrofit = builder.build();
        return retrofit;
    }
    @Provides
    @Singleton
    public Api provideApi(Retrofit retrofit){
        return retrofit.create(Api.class);
    }

    @Provides
    @Singleton
    public LinearLayoutManager getLayoutManager(@ApplicationContext Context context){
        return new LinearLayoutManager(context,LinearLayoutManager.HORIZONTAL,false);
    }
    @Provides
    public MainItemAdapter provideMainItemAdapter(){
        return new MainItemAdapter();
    }
    @Provides
    public MainBrandsAdapter provideMainBrandsAdapter(){
        return new MainBrandsAdapter();
    }
    @Provides
    public MainProductAdapter provideMainProductAdapter(){
        return new MainProductAdapter();
    }

    @Provides
    @Singleton
    public CompositeDisposable provideCompositeDisposable(){
        return new CompositeDisposable();
    }

    @Provides
    public CategoryAdapter provideCategoryAdapter(){
        return new CategoryAdapter();
    }



    @Singleton
    @Provides
    public ProgressDialog provideDialog(@ApplicationContext Context context)
    {
        return new ProgressDialog(context);
    }

    @Provides
    public SubCategoryAdapter provideSubCatAdapter(){
        return new SubCategoryAdapter();
    }

    @Provides
    public ProductAdapter provideProductAdapter(){
        return new ProductAdapter();
    }

    @Singleton
    @Provides
    public GridLayoutManager provideGridLayoutManager(@ApplicationContext Context context){
        return new GridLayoutManager(context,2);
    }

    @Singleton
    @Provides
    @userToken
    public static SharedPreferences provideUserToken(@ApplicationContext Context context){
        return context.getSharedPreferences("userToken",Context.MODE_PRIVATE);
    }


    @Qualifier
    @Retention(RetentionPolicy.RUNTIME)
    public  @interface userToken{}

}
