package com.example.brimore2.ui.product_details;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.brimore2.R;
import com.example.brimore2.data.Modules;
import com.example.brimore2.data.models.products.Datum;
import com.example.brimore2.data.models.products.Variant;
import com.example.brimore2.databinding.FragmentProductDetailsBinding;

import java.util.List;

import javax.inject.Inject;

public class ProductDetailsFragment extends Fragment {
    private static final String TAG = "ProductDetailsFragment";
    ProductsDetailsViewModel viewModel;


    SharedPreferences userPref;
    public ProductDetailsFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        FragmentProductDetailsBinding binding = DataBindingUtil.inflate(inflater,R.layout.fragment_product_details,container,false);
        View view = binding.getRoot();
        userPref = requireActivity().getSharedPreferences("userToken",Context.MODE_PRIVATE);
        String token = userPref.getString("token", "");
        SharedPreferences idPref = requireActivity().getSharedPreferences("subCatId", Context.MODE_PRIVATE);
        int id = idPref.getInt("id", 0);
        viewModel = new ViewModelProvider(requireActivity()).get(ProductsDetailsViewModel.class);
        viewModel.getProductsDetails(token,id);

        viewModel.mutableLiveData.observe(requireActivity(), new Observer<List<Datum>>() {
            @Override
            public void onChanged(List<Datum> variants) {
                Log.d(TAG, "aly onChanged: "+variants);
            }
        });

        return view;
    }
}