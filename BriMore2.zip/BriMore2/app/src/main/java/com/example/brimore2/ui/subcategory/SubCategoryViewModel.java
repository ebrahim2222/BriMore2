package com.example.brimore2.ui.subcategory;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.brimore2.data.Repositories;
import com.example.brimore2.data.models.categories.Categories;
import com.example.brimore2.data.models.main.maincategory.MainCategoryDetails;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;
import dagger.hilt.android.qualifiers.ApplicationContext;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

@HiltViewModel
public class SubCategoryViewModel extends ViewModel {

    MutableLiveData<List<MainCategoryDetails>> mutableLiveData = new MutableLiveData<>();

    Repositories repositories;
    CompositeDisposable compositeDisposable;
    Context context;
    private static final String TAG = "SubCategoryViewModel";

    @Inject
    public SubCategoryViewModel(Repositories repositories, CompositeDisposable compositeDisposable, @ApplicationContext Context context) {
        this.compositeDisposable = compositeDisposable;
        this.repositories = repositories;
        this.context = context;
    }

    public void getSubCategory(String header , int id){

        Observable<Categories> subCategoryApi = repositories.getSubCategoryApi("Bearer "+header, id);
        compositeDisposable.add(subCategoryApi.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer<Categories>() {
            @Override
            public void accept(Categories categories) throws Exception {
                List<MainCategoryDetails> data = categories.getData();
                mutableLiveData.setValue(data);
            }
        }, new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                Toast.makeText(context, throwable.getMessage(), Toast.LENGTH_SHORT).show();
                Log.d(TAG, "aly accept: "+throwable.getMessage());
            }
        }));

    }
}
